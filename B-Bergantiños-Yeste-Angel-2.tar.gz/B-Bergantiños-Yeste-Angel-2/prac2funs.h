#ifndef FUNCTIONS_PRAC2_INCLUDED
#define FUNCTIONS_PRAC2_INCLUDED

void dif_dividides(double*,double*,int);
double aval(double*,double*,int,double);

#endif
